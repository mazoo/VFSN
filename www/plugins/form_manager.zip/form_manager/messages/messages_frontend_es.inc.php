<?php
/**

Deutsche Text-Daten des Plugins "form_manager" für das Frontend

!! Diese Datei muss im Format "Utf-8 (NoBOM)" gespeichert werden !!!

*/

$this->content->template['plugin']['form_manager']['bitte_korrek'] = 'Por favor, corrija las siguientes entradas:';
$this->content->template['plugin']['form_manager']['senden'] = 'Enviar';

$this->content->template['plugin']['form_manager']['fehlermeldung'] = 'Corregir, por favor: ';
$this->content->template['plugin']['form_manager']['anwensenden'] = '¿A quién quiere enviar el formulario? ';

$this->content->template['message']['plugin']['form_manager']['replace']['yes'] = 'Sí';
$this->content->template['message']['plugin']['form_manager']['replace']['no'] = 'No';

?>