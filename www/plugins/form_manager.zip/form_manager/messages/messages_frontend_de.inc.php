<?php
$this->content->template['plugin']['form_manager']['bitte_korrek'] = 'Bitte korrigieren Sie die folgenden Einträge:';
$this->content->template['plugin']['form_manager']['senden'] = 'Absenden';
$this->content->template['plugin']['form_manager']['fehlermeldung'] = 'Bitte korrigieren: ';
$this->content->template['plugin']['form_manager']['anwensenden'] = 'An wen soll das Formular versendet werden? ';
$this->content->template['message']['plugin']['form_manager']['replace']['yes'] = 'Ja';
$this->content->template['message']['plugin']['form_manager']['replace']['no'] = 'Nein';
$this->content->template['message']['plugin']['form_manager']['replace']['spamschutz'] ='Spamschutz';
$this->content->template['message']['plugin']['form_manager']['replace']['sendto'] = 'Formular-Empfänger';
?>