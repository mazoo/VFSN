<?php
/**

english text-data of plugin "form_manager" for the frontend.

!!! this file must be saved as "UTF-8 (No BOM)" !!!

*/

$this->content->template['plugin']['form_manager']['bitte_korrek'] = 'Please correct the following entries:';
$this->content->template['plugin']['form_manager']['senden'] = 'Submit';

$this->content->template['plugin']['form_manager']['fehlermeldung'] = 'Please correct:';
$this->content->template['plugin']['form_manager']['anwensenden'] = 'Who would you like to send the form to? ';

$this->content->template['message']['plugin']['form_manager']['replace']['yes'] = 'Yes';
$this->content->template['message']['plugin']['form_manager']['replace']['no'] = 'No';
$this->content->template['message']['plugin']['form_manager']['replace']['spamschutz'] ='Spam protection';
$this->content->template['message']['plugin']['form_manager']['replace']['sendto'] = 'Recipient';

?>