<?php 
/**
* Deutsche Text-Daten des Plugins "form_manager" für das Backend
* !! Diese Datei muss im Format "UTF-8 (NoBOM)" gespeichert werden !!!
*/
 
$this->content->template['plugin']['form_manager']['bitte_korrek']='Ваша:';
$this->content->template['plugin']['form_manager']['senden']='Отправить';
$this->content->template['plugin']['form_manager']['fehlermeldung']='Ваша:';

$this->content->template['message']['plugin']['form_manager']['replace']['yes'] = 'Yes';
$this->content->template['message']['plugin']['form_manager']['replace']['no'] = 'No';

?>