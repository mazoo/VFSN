DROP TABLE IF EXISTS `XXX_cookiemanager_cookies`; ##b_dump##
CREATE TABLE `XXX_cookiemanager_cookies` (

) ENGINE=MyISAM; ##b_dump##



