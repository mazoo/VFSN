CREATE TABLE `XXX_plugin_cookiemana_cookiemana_form` (`cookiemana_id` int(11) NOT NULL auto_increment, 
				  							PRIMARY KEY (`cookiemana_id`)) ENGINE=MyISAM; ##b_dump##
ALTER TABLE `XXX_plugin_cookiemana_cookiemana_form` ADD `cookiemana_cookie_name` TEXT; ##b_dump##
ALTER TABLE `XXX_plugin_cookiemana_cookiemana_form` ADD `cookiemana_cookie_kategorie` VARCHAR( 255 ) NOT NULL; ##b_dump##
ALTER TABLE `XXX_plugin_cookiemana_cookiemana_form` ADD `cookiemana_beschreibung` TEXT; ##b_dump##
ALTER TABLE `XXX_plugin_cookiemana_cookiemana_form` ADD `cookiemana_unternehmen_das_die_daten_verarbeitet` TEXT; ##b_dump##
ALTER TABLE `XXX_plugin_cookiemana_cookiemana_form` ADD `cookiemana_datenverarbeitungszwecke` TEXT; ##b_dump##
ALTER TABLE `XXX_plugin_cookiemana_cookiemana_form` ADD `cookiemana_genutzte_technologien` TEXT; ##b_dump##
ALTER TABLE `XXX_plugin_cookiemana_cookiemana_form` ADD `cookiemana_gesammelte_daten` TEXT; ##b_dump##
ALTER TABLE `XXX_plugin_cookiemana_cookiemana_form` ADD `cookiemana_rechtliche_grundlage` TEXT; ##b_dump##
ALTER TABLE `XXX_plugin_cookiemana_cookiemana_form` ADD `cookiemana_ort_der_verarbeitung` TEXT; ##b_dump##
ALTER TABLE `XXX_plugin_cookiemana_cookiemana_form` ADD `cookiemana_aufbewahrungsfrist` TEXT; ##b_dump##
ALTER TABLE `XXX_plugin_cookiemana_cookiemana_form` ADD `cookiemana_transfer_to_third_countries` TEXT; ##b_dump##
ALTER TABLE `XXX_plugin_cookiemana_cookiemana_form` ADD `cookiemana_weitere_informationen_und__oder_optout` TEXT; ##b_dump##
ALTER TABLE `XXX_plugin_cookiemana_cookiemana_form` ADD `cookiemana_datenschutzbeauftragter` TEXT; ##b_dump##
