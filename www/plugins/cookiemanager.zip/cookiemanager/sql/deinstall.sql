DROP TABLE IF EXISTS `XXX_cookiemanager_cookies`; ##b_dump##

DROP TABLE IF EXISTS `XXX_plugin_cookiemana_cookies`; ##b_dump##
DROP TABLE IF EXISTS `XXX_plugin_cookiemana_cookiemana_form`; ##b_dump##
