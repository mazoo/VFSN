<?php

/**
 * Hauptdatei für das cookiemanager-Plugin.
 *
 * @author Papoo Software & Media GmbH Dr. Carsten Euwens <info@papoo.de>
 */

/**
 * class cookiemanager_class
 *
 * Hauptklasse des Plugins.
 *
 * @author Papoo Software & Media GmbH Dr. Carsten Euwens <info@papoo.de>
 */
class cookiemanager_class
{
	const PREFIX = 'cookiemana';

	/**
	 * cookiemanager_class constructor.
	 */
	function __construct()
	{
		global $user, $db_abs, $db, $db_praefix, $checked, $content;
		$this->user = &$user;
		$this->db_abs = &$db_abs;
		$this->db = &$db;
		$this->db_praefix = &$db_praefix;
		$this->checked = &$checked;
		$this->content = &$content;

		if(defined('admin')) {
			$this->user->check_intern();
			global $template;
			$template2 = str_ireplace( PAPOO_ABS_PFAD . '/plugins/', '', $template );
			$template2 = basename( $template2 );

			if ( $template != 'login.utf8.html' ) {
				if(stristr($template2, "cookiemanager")){
					// Pfad zum css Ordner zur Einbindung des backend css
					$this->content->template['css_path'] = $css_path = PAPOO_WEB_PFAD.'/plugins/cookiemanager/css';

					$this->rapid_dev();

					// TODO: Backend logic hierhin
                    //  logic hierhin
                    $this->DoPageNavi();
				}
			}
		}
		else {
			// TODO: Frontend logic hierhin
		}
	}


    /**
     *
     *
     * BACKEND LOGIK
     */

    private function DoPageNavi()
    {
        //debug::print_d($this->checked->plugin_produktnav_form_tablename);
        $this->content->template['self_cm_link']="plugin.php?menuid=".$this->checked->menuid."&template=cookiemanager/templates/cookiemanager_backend.html";

        if ($this->checked->eingetragen=="ok")
        {
            $this->content->template['is_eingetragen']="ok";
        }

        //Nicht genutzten Eintrag löschen
        if (is_numeric($this->checked->cm_del_id))
        {

            #$this->delete_entry($this->checked->cm_id);

        }
        if (!empty($this->checked->cm_id))
        {
            //template setzen
            $this->content->template['new_cm_ok']="OK";

            $this->manage_entries();
        }
        else
        {
            #$this->get_all_cm();
        }

    }


    /**
     * Damit auch die null werte übertragen werden und abgehackt werden können
     */
    private function preset_checkboxes()
    {

        if (empty($this->checked->speciallan_alle_angebote))
        {
            $this->checked->speciallan_alle_angebote=0;
        }
        if (empty($this->checked->speciallan_fitness))
        {
            $this->checked->speciallan_fitness=0;
        }
        if (empty($this->checked->speciallan_massage))
        {
            $this->checked->speciallan_massage=0;
        }
        if (empty($this->checked->speciallan_racketsport))
        {
            $this->checked->speciallan_racketsport=0;
        }
        if (empty($this->checked->speciallan_sauna))
        {
            $this->checked->speciallan_sauna=0;
        }
        if (empty($this->checked->speciallan_schwimmen))
        {
            $this->checked->speciallan_schwimmen=0;
        }
        if (empty($this->checked->speciallan_specials))
        {
            $this->checked->speciallan_specials=0;
        }

    }


    /**
     * alle PNav Einträge rausholen und auflisten
     */
    private function get_all_cm()
    {
        $this->db->hide_errors();$this->db->show_errors();

        $xsql=array();
        $xsql['dbname']         = "plugin_speciallan_landingpag_form";
        $xsql['select_felder']  = array("*");
        $xsql['where_data_like']= " LIKE ";
        $xsql['where_data']     = array("speciallan_id" => "%%");

        $result = $this->db_abs->select( $xsql);
        //debug::print_d($result);
        $this->content->template['cm_liste']=$result;

        $this->db->show_errors();

    }


    /**
     * Einen Eintrag rausholen
     */
    private function get_cm()
    {
        if (is_numeric($this->checked->cm_id))
        {
            $xsql=array();
            $xsql['dbname']         = "plugin_speciallan_landingpag_form";
            $xsql['select_felder']  = array("*");
            $xsql['limit']          = " LIMIT 1";
            $xsql['where_data']     = array("speciallan_id" => $this->checked->cm_id);
            $result = $this->db_abs->select( $xsql );

            $this->content->template['speciallan']=$result;

        }
    }

    /**
     *
     */
    private function delete_entry()
    {
        $xsql=array();
        $xsql['dbname']         = "plugin_speciallan_landingpag_form";
        $xsql['limit']          = " LIMIT 1";
        $xsql['del_where_wert'] = " speciallan_id='".$this->db->escape($this->checked->cm_del_id)."' ";
        $result = $this->db_abs->delete( $xsql );
    }

    /**
     * @return bool
     * Die Einträge managen - insert / update
     */
    private function manage_entries()
    {

        //var_dump($this->checked);exit();
        //Daten eines Eintrages
        $this->get_cm();

        //Die Sitemap setzen
        //$this->set_sitemap();

        //Nicht abgeschickt, dann nix machen
        if (empty($this->checked->plugin_speciallan_form_submit))
        {
            return false;
        }

        if (!is_numeric($this->checked->cm_id))
        {
            $xsql=array();
            $xsql['dbname']     = "plugin_speciallan_landingpag_form";
            $xsql['praefix']    = "speciallan_";
            $xsql['must']       = array( "speciallan_urldat" );

            $cat_dat = $this->db_abs->insert( $xsql);
            $insertid=$cat_dat['insert_id'];

            if (is_numeric($insertid))
            {
                $this->reload($insertid);
            }
        }
        else
        {

            $this->preset_checkboxes();

            //exit("EXIT BEVORE SAVE STATUS");

            $xsql=array();
            $xsql['dbname']         = "plugin_speciallan_landingpag_form";
            $xsql['praefix']        = "speciallan_";
            $xsql['must']           = array( "speciallan_urldat" );
            $xsql['where_name']     = "speciallan_id";


            $cat_dat = $this->db_abs->update( $xsql,1 );

            $insertid=$cat_dat['insert_id'];
            //debug::print_d($insertid);
            if (is_numeric($insertid))
            {
                $this->reload($insertid);
            }
        }
    }




    /**
     * @param string $pnavid
     * Seite mit der ID neu laden damit die Daten geladen werden können
     *
     */
    private function reload($pnavid="")
    {
        $location_url = "plugin.php?menuid=".$this->checked->menuid."&template=cookiemanager/templates/cookiemanager_backend.html&eingetragen=ok&cm_id=".$pnavid;
        if ($_SESSION['debug_stopallvar'])
            echo '<a href="' . $location_url . '">' .
                $this->content->template['plugin']['mv']['weiter'] . '</a>';
        else  header("Location: $location_url");
        exit;
    }






















    /**
	 * @param $plugin_name
	 * @return string|null
	 */
	static public function ToSecureName($plugin_name)
	{
		$matches = array();

		if(!preg_match_all("/[a-zA-Z]+/", $plugin_name, $matches)) {
			return NULL;
		}

		$plugin_name = "";

		foreach($matches[0] as $match) {
			$plugin_name .= $match;
		}

		return strtolower($plugin_name);
	}

	/**
	 * @return bool|string
	 */
	public function GetShortPrefix()
	{
		return self::ShortName(self::PREFIX);
	}

	/**
	 * @param $input
	 * @return bool|string
	 */
	static public function ShortName($input)
	{
		return substr(self::ToSecureName($input), 0, 10);
	}

	/**
	 * Funktion die die Übertragung der rapid dev Form Daten in die Datenbank übernimmt.
	 *
	 * @uses db_abs
	 */
	private function rapid_dev()
	{
		$this->rapid_dev_insert("cookiemanager");
$this->rapid_dev_templify("cookiemanager");

	}

	/**
	 * Holt den Inhalt der $tabelle aus der Datenbank als assoziatives array.
	 *
	 * Beispiel:
	 *  $this->get_results("testbackend", "SELECT * FROM %%"); // => enthält alle eintrage von testbackend
	 *
	 * @param string $tabelle
	 * @param string $sql SQL das ausgeführt werden soll. %% im string wird durch die übergebene Tabelle ersetzt.
	 * @param string $get_mode
	 * @return array
	 */
	private function get_results($tabelle, $sql, $get_mode = ARRAY_A)
	{
		$tabellenname = $this->db_praefix . "plugin_" . $this->GetShortPrefix() . "_" . self::ShortName($tabelle) . "_form";
		$sql = preg_replace("/(?<!%)%%(?!%)/", $tabellenname, $sql);
		return $this->db->get_results($sql, $get_mode);
	}

	/**
	 * @param $tabelle
	 * @param $sql
	 * @return bool|int|mixed|mysqli_result|void
	 */
	private function query($tabelle, $sql)
	{
		$tabellenname = $this->db_praefix . "plugin_" . $this->GetShortPrefix() . "_" . self::ShortName($tabelle) . "_form";
		$sql = preg_replace("/(?<!%)%%(?!%)/", $tabellenname, $sql);
		return $this->db->query($sql);
	}

	/**
	 * @param $tabelle
	 */
	private function rapid_dev_templify($tabelle)
	{
		$tabellenname = "plugin_" . $this->GetShortPrefix() . "_" . self::ShortName($tabelle) . "_form";

		global $db_name;
		$sql = "SELECT DISTINCT COLUMN_NAME FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_NAME='{$this->db_praefix}{$tabellenname}' AND TABLE_SCHEMA='$db_name';";
		$labels = $this->db->get_results($sql, ARRAY_A);

		// Falls die Tabelle noch garnicht existiert
		if(!empty($labels)) {
			$this->content->template['plugin'][$this->GetShortPrefix()]['rapid_dev'][$tabellenname]['labels'] = $labels;

			$sql = "SELECT * FROM " . $this->db_praefix . $tabellenname;
			$this->content->template['plugin'][$this->GetShortPrefix()]['rapid_dev'][$tabellenname]['data'] = $this->db->get_results($sql, ARRAY_A);
		}
	}

	/**
	 * @param $tabelle
	 * @return null
	 */
	private function rapid_dev_insert($tabelle)
	{
		$tabellenname = "plugin_" . $this->GetShortPrefix() . "_" . self::ShortName($tabelle) . "_form";
		$abgesendete_tabelle = "plugin_" . $this->GetShortPrefix() . "_form_tablename";

		if(isset($_REQUEST[$abgesendete_tabelle]) and
			$_REQUEST[$abgesendete_tabelle] == "plugin_" . $this->GetShortPrefix() . "_" . self::ShortName($tabelle) . "_form") {
			$xsql = array();
			$xsql["dbname"] = $tabellenname;
			$xsql["praefix"] = $this->GetShortPrefix();

			// Siehe http://stackoverflow.com/questions/4142809/simple-post-redirect-get-code-example
			header("Location: " . $_SERVER['REQUEST_URI']);

			return $this->db_abs->insert($xsql)['insert_id'];
		}
		return NULL;
	}

	/**
	 * Funktion die vor dem Senden des Seiteninhalts für jedes Plugin aufgerufen wird,
	 * bei der dann per global $output und z.B. einem regulären Ausdruck der Inhalt
	 * verändert werden kann.
	 * (Backend)
	 */
	public function output_filter_admin()
	{
		#global $output;
	}

	/**
	 * Funktion die vor dem Senden des Seiteninhalts für jedes Plugin aufgerufen wird,
	 * bei der dann per global $output und z.B. einem regulären Ausdruck der Inhalt
	 * verändert werden kann.
	 * (Frontend)
	 */
	public function output_filter()
	{
		#global $output;
	}
}

$cookiemanager = new cookiemanager_class();
