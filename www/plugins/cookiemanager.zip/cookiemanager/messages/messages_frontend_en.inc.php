<?php
/**

Englische Text-Daten des Plugins "CookieManager" für das Frontend


*/

#start#
?>