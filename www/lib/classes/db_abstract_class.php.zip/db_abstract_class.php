<?php

// #####################################
// # CMS Papoo                         #
// # (c) Carsten Euwens 2009           #
// # Authors: Carsten Euwens           #
// # http://www.papoo.de               #
// # Internet                          #
// #####################################
// # PHP Version 5                     #
// #####################################
/*
*/

/* --------------------------------------------------------------------
* Diese Klasse bietet eine DB ABstraktion
* Normale Statements brauchen nicht mehr gebaut zu werden hiermit
* Voraussetzung ist das die Variablen im Template gleich heissen wie
* die DB Felder,
*
* ----------------------------------------------------------------------*/

class db_abs
{
    // Konstruktor
    function __construct()
    {
        /**
         * Klassen globalisieren
         */

        // cms Klasse einbinden
        global $cms;
        $this->cms = &$cms;
        // einbinden des Objekts der Datenbak Abstraktionsklasse ez_sql
        global $db;
        $this->db = &$db;
        //Content Klasse
        global $content;
        $this->content = &$content;

        global $checked;
        $this->checked = &$checked;

    }

    public function show_version()
    {
        $this->version = 2;
    }

    function get_colums_from_db($db = "")
    {
        //debug::print_d($this->cms->tbname);
        if (!empty($this->cms->tbname[$db])) {
            $sql = sprintf("SHOW COLUMNS FROM %s",
                $this->cms->tbname[$db]
            );
            //debug::print_d($sql);
            $colums = $this->db->get_results($sql, ARRAY_A);
        }
        #print_r($colums);
        if (empty($colums)) {
            $colums = array();
        }
        foreach ($colums as $col) {
            $cols[] = $col['Field'];
        }
        return $cols;
        #print_r($cols);
    }

    /**
     * FUNCTION: validateEmail
     *
     * Validates an email address and return true or false.
     *
     * @param string $address email address
     * @return bool true/false
     * @access public
     */
    function validateEmail($address)
    {
        return preg_match('/^[_a-z0-9-]+(\.[_a-z0-9-]+)*@[a-z0-9_-]+(\.[_a-z0-9-]+)+$/i', $address);
    }


    /**
     * shop_class::hole_passende_eintraege_aus_checked_raus()
     * Holt die Vars aus dem checked Objekt die passend zur Tabelle sind.
     * @param mixed $xpr
     * @return
     */
    function hole_passende_eintraege_aus_checked_raus($xpr, $must, $not = "xyzxyz", $db = "", $lang_name = "")
    {
        //INI
        $ret = array();

        $count = 0;
        $return_to_template = array();
        if (empty($not)) $not = "xyzxyz";

        //Alle felder Rausholen die passen koennten
        $cols = $this->get_colums_from_db($db);
        //print_r($cols);

        //Anzahl der MUST Felder
        if (!$must) {
            $must = array();
        }
		    $must_count = is_array($must) || $must instanceof Countable ? count($must) : 0;
        if (is_array($cols)) {
            /**
             * foreach ($cols as $keyc => $valuec)
             * {
             *     #echo $lang_name;
             *     #echo "<br />";
             *     #echo $valuec;
             *     if (empty($this->checked->$valuec))
             *     {
             *         if (!empty($lang_name))
             *         {
             *             if ($xpr. "_lang_id"==$valuec)
             *             {
             *                 #continue;
             *             }
             *         }
             *         //$xsql['praefix'] . "_lang_id='"
             *         #$this->checked->$valuec="";
             *     }
             * }
             */

            //Die checked Daten durchgehen
            foreach ($this->checked as $key => $value) {
                //sicherstellen dass es sich nur um korrekte Zeichen handelt
                $key = preg_replace("/[^a-zA-Z0-9_]_/", "", $key);
                #echo "<br />";
                //Wenn vorkommt in Returm Array uebergeben
                //alt: eregi($xpr, $key) && !eregi($not,$key) &&
                if (in_array($key, $cols)) {
                    $ret[$key] = $value;

                    //WEnn Eintrag enthalten ist, eintragen
                    if (!empty($value)) {
                        //WEnn der Eintrag auch im Must Array ist den Zaehler hochsetzen
                        if (is_array($must)) {
                            if (in_array($key, $must)) {
                                $count++;
                            }
                        }
                    }
                    //Nochmal DAten ausgeben
                    $return_to_template['0'][$key] = "nobr:" . $value;
                } else {
                    //Nochmal DAten ausgeben
                    $this->content->template[$key] = "nobr:" . $value;
                }
            }
        }
        //DAten
        @$this->content->template[$xpr] = $return_to_template;

        #echo $count;
        #echo "<br />";
        ##echo $must_count;
        #debug::print_d($this->checked);
        #    debug::print_d($must);
        #exit();
        #echo "<br />";
        //Wenn alle drin
        if ($count == $must_count) {
            $this->alle_must_enthalten = 1;
        } //Nicht alle drin
        else {

            //Eintraege durchgehen
            if (is_array($must)) {
                foreach ($must as $var) {
                    if (empty($this->checked->$var)) {
                        if ($var != "extended_user_email") {
                            $this->content->template['plugin_error'][$var] = $this->content->template['plugin_shop_fehlt_eintrag'];
                        } else {
                            #echo $this->checked->$var;
                            if (!empty($this->checked->extended_user_email_false)) {

                                $this->content->template['plugin_error'][$var] = $this->content->template['plugin_shop_fehlt_eintrag'];
                                $this->content->template['plugin_error_email_false'][$var] = $this->content->template['plugin_shop_fehlt_eintrag'];


                            } else {
                                $this->content->template['plugin_error'][$var] = $this->content->template['plugin_shop_fehlt_eintrag_email_exist'];
                            }
                        }
                    } else {
                        if ($var == "extended_user_email") {
                            if (!$this->validateEmail($this->checked->$var)) {
                                $this->content->template['plugin_error'][$var] = $this->content->template['plugin_shop_fehlt_eintrag_email_falsch'];
                            }
                        }
                    }

                }
            }
        }
        if (is_array($must)) {
            foreach ($must as $var) {
                if ($var == "extended_user_email") {
                    #echo $this->checked->$var;
                    if (!$this->validateEmail($this->checked->$var)) {
                        $this->content->template['plugin_error'][$var] = $this->content->template['plugin_shop_fehlt_eintrag_email_falsch'];
                        $this->alle_must_enthalten = "";
                    }
                }
                //extended_user_benutzername_false
                if ($var == "extended_user_benutzername") {
                    #echo $this->checked->$var;
                    if (($this->checked->extended_user_benutzername_false)) {
                        $this->content->template['plugin_error'][$var] = $this->content->template['plugin_shop_fehlt_eintrag_username_falsch'];
                        $this->alle_must_enthalten = "";
                    }
                }

            }
        }
        #print_r($this->content->template['plugin_error']);
        #print_r($must);
        if (!is_array($must)) {
            $this->alle_must_enthalten = 1;
        }
        #print_r($this->content->template['error']);
        #exit();
        #print_r($ret);
        return $ret;
    }


    /**
     * shop_class::insert_new_eintrag_in_shop_db()
     * Neuen Eintrag in eine uebergeben Tabelle erstellen
     * @param mixed $xsql
     * @return mixed|void
     */
    function insert($xsql, $show = 0)
    {
        //Initialisierung
        $insert = "";

        //Neu setzen
        $this->alle_must_enthalten = 0;

        //Die passenden Eintraege rausholen
        $post_vars = $this->hole_passende_eintraege_aus_checked_raus($xsql['praefix'], $xsql['must'], $xsql['not_praefix'], $xsql['dbname'], $xsql['lang_id']);

        //Die durchgehen und Statement erstellen
        foreach ($post_vars as $key => $value) {
            $insert .= $key . "='" . $this->db->escape($value) . "', ";
        }

        //Sprachid setzen
        if (!empty($xsql['lang_id'])) {
            $insert .= $xsql['praefix'] . "_lang_id='" . $xsql['lang_id'] .
                "', ";
        }

        $insert = substr($insert, 0, -2);

        //Statement erzeugen
        $sql = sprintf("INSERT INTO %s SET %s",
            $this->cms->tbname[$xsql['dbname']],
            $insert
        );
        $this->alle_must_enthalten;
        //Wenn was drin ist
        if ($this->alle_must_enthalten == 1) {
            //Insert durchfuehren
            $this->db->query($sql);

            //Wenn anzeigen
            if ($show == 1) {
                echo $sql;
            }

            //Id uebergeben
            $return['insert_id'] = $this->db->insert_id;


        } else {
            //Wenn anzeigen
            if ($show == 1) {
                echo "NICHT ALLE ENTHALTEN";
            }


            //Werte wieder zurueckgeben
            $this->werte_nochmal_zurueckgeben();
        }

        return $return;
    }

    /**
     * shop_class::insert_new_eintrag_in_shop_db()
     * Neuen Eintrag in eine uebergeben Tabell erstellen
     * @param mixed $xsql
     * @return void
     */
    function delete($xsql, $show = "")
    {
        //Initialisierung
        $insert = "";

        //Statement erzeugen
        $sql = sprintf("DELETE FROM %s WHERE %s %s",
            $this->cms->tbname[$xsql['dbname']],
            $xsql['del_where_wert'],
            $xsql['limit']
        );
        if ($show == 1) {
            echo $sql;
        }
        //Loeschen durchfuehren
        $return = $this->db->query($sql);

        return $return;
    }

    /**
     * shop_class::insert_new_eintrag_in_shop_db()
     * Neuen Eintrag in eine uebergeben Tabell erstellen
     * @param mixed $xsql
     * @return void
     */
    function update($xsql, $show = 0)
    {
        //Initialisierung
        $insert = "";

        if (defined("admin")) {
            unset($_SESSION['shop_settings']);
        }

        //Neu setzen
        $this->alle_must_enthalten = 0;
        #echo $xsql['where_lang_name'];
        #exit();
        //Die passenden Eintraege rausholen

        $post_vars = $this->hole_passende_eintraege_aus_checked_raus($xsql['praefix'], $xsql['must'], $xsql['not_praefix'], $xsql['dbname'], $xsql['where_lang_name']);

        //Die durchgehen und Statement erstellen
        foreach ($post_vars as $key => $value) {
            $insert .= $key . "='" . $this->db->escape($value) . "', ";
        }


        if (!empty($xsql['where_lang_name'])) {
            #echo $this->cms->lang_back_content_id;
            //Sprachid setzen
            $insert .= $xsql['praefix'] . "_lang_id='" . $this->cms->lang_back_content_id .
                "'";


            //Statement erzeugen
            $sql = sprintf("UPDATE %s SET %s WHERE %s='%d' AND %s='%s' LIMIT 1",
                $this->cms->tbname[$xsql['dbname']],
                $insert,
                $xsql['where_name'],
                $this->db->escape($this->checked->{$xsql['where_name']}),
                $xsql['where_lang_name'],
                $this->db->escape($this->cms->lang_back_content_id)
            );
        } else {
            $insert = substr($insert, 0, -2);
            //Statement erzeugen
            $sql = sprintf("UPDATE %s SET %s WHERE %s='%s' LIMIT 1",
                $this->cms->tbname[$xsql['dbname']],
                $insert,
                $xsql['where_name'],
                $this->db->escape($this->checked->{$xsql['where_name']})
            );
        }

        //Wenn was drin ist
        if ($this->alle_must_enthalten == 1) {
            #echo $sql;
            //Wenn anzeigen
            if ($show == 1) {
                echo $sql;
            }

            //Insert durchfuehren
            $this->db->query($sql);
            #echo $xsql['where_name'];
            //Id uebergeben
            $return['insert_id'] = $this->checked->{$xsql['where_name']};


        } else {
            #echo "reture";
            //Werte wieder zurueckgeben
            $this->werte_nochmal_zurueckgeben();
        }

        return $return;
    }

    /**
     * @param $xsql
     * @param int $show
     * @return array|null|string
     *
     * Select auf eine DB Tabelle ausführen
     */

    function select($xsql, $show = 0)
    {
        //Initialisierung
        $select = "";
        $select_felder = "";

        if (defined("admin")) {
            unset($_SESSION['shop_settings']);
        }

        //Neu setzen
        #$this->alle_must_enthalten = 0;
        #echo $xsql['where_lang_name'];
        #exit();
        //Die passenden Eintraege rausholen
        #$post_vars = $this->hole_passende_eintraege_aus_checked_raus($xsql['praefix'], $xsql['must'],$xsql['not_praefix'],$xsql['dbname']);

        if (!is_array($xsql['where_data'])) {
            return "where_data ist KEIN ARRAY";
        }

        if (!is_array($xsql['select_felder'])) {
            return "select_felder ist KEIN ARRAY";
        }

        if (empty($xsql['where_data_like'])) {
            $compare = " = ";
        } else {
            $compare = " LIKE ";
        }

        //Die durchgehen und Statement erstellen
        foreach ($xsql['where_data'] as $key => $value) {
            $select .= $key . $compare . "'" . $this->db->escape($value) . "' AND ";
        }

        if (!isset($xsql['where_not_data'])) {
            $xsql['where_not_data'] = NULL;
        }
        if (!isset($xsql['group_by'])) {
            $xsql['group_by'] = NULL;
        }
        if (!isset($xsql['order_by'])) {
            $xsql['order_by'] = NULL;
        }
        if (!isset($xsql['order_by_asc_desc'])) {
            $xsql['order_by_asc_desc'] = null;
        }

        if (is_array($xsql['where_not_data'])) {
            foreach ($xsql['where_not_data'] as $key => $value) {
                $select .= $key . $compare . " '" . $this->db->escape($value) . "' AND ";
            }
        }

        //Letztes AND raus
        $select = substr($select, 0, -4);

        //Die Felder durchgehen und Statement erstellen
        foreach ($xsql['select_felder'] as $key => $value) {
            $select_felder .= $value . ", ";
        }

        //Letztes Komma raus...
        $select_felder = substr($select_felder, 0, -2);

        if (!empty($xsql['group_by'])) {
            $xsql['group_by'] = " GROUP BY " . $xsql['group_by'];
        }

        if (!empty($xsql['order_by'])) {
            $xsql['order_by'] = " ORDER BY " . $xsql['order_by'];
        }

        if (!empty($xsql['order_by_asc_desc'])) {
            $xsql['order_by_asc_desc'] = " " . $xsql['order_by_asc_desc'];
        }

        IfNotSetNull($xsql['limit']);

        $sql = sprintf("SELECT %s FROM %s WHERE %s %s %s %s %s",
            $this->db->escape($select_felder),
            $this->cms->tbname[$xsql['dbname']],
            $select,
            $this->db->escape($xsql['group_by']),
            $this->db->escape($xsql['order_by']),
            $this->db->escape($xsql['order_by_asc_desc']),
            $this->db->escape($xsql['limit'])
        );
        #echo $sql;
        //debug::print_d($sql);
        if ($show == 1) {
            debug::print_d($sql);
        }

        $return = $this->db->get_results($sql, ARRAY_A);

        return $return;
    }


    /**
     * shop_class::werte_nochmal_zurueckgeben()
     * Gibt alle Werte nochmal ans Template zurueck
     * @return void
     */
    function werte_nochmal_zurueckgeben()
    {
        //Nachricht uebergeben
        $this->content->template['is_eingetragen'] = "no";
    }

}

// Hiermit wird die Klasse initialisiert und kann damit sofort ueberall benutzt werden.
$db_abs = new db_abs();
