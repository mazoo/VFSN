<?php

/**
######################################
# CMS Papoo                  #
# (c) Dr. Carsten Euwens 2008        #
# Authors: Carsten Euwens            #
# http://www.papoo.de                #
# Internet                           #
######################################
# PHP Version 4.2                    #
######################################


*/

class download_class
{
	var $infos_anzeigen; // Soll Download-Link mit weiteren Informationen angezeigt werden? (z.B. Anzahl-Downloads, Icon oder Datum letzter Download)
	var $max_datei_groesse; // maximale Datei-Gr��e [Byte] f�r "direkten Download. Gr��ere Dateien werden per Meta-Refresh "heruntergeladen"

	function __construct()
	{
		// einbinden des Objekts der Datenbak Abstraktionsklasse ez_sql
		global $db;
		$this->db = & $db;
		// cms Klasse einbinden
		global $cms;
		$this->cms = & $cms;
		// User Klasse einbinden
		global $user;
		$this->user = & $user;
		// Checked-Klasse einbinden
		global $checked;
		$this->checked = & $checked;
		// content-Klasse einbinden
		global $content;
		$this->content = & $content;

		// lokale Variblen initialisieren
		$this->infos_anzeigen = 1;
		$this->max_datei_groesse = 0;

		$this->make_download();
	}

	// Aktions-Weiche der Download-Klasse
	function make_download()
	{
		if(@$this->checked->downloadid) {
            $this->download_file($this->checked->downloadid);
        }
	}

	function do_redirect($uri)
	{
		header("HTTP/1.1 301 Moved Permanently");
		header("Location: ".$uri);
		header("Connection: close");
		exit();die();

	}

	// @descrip: den Download durchf�hren
	function download_file($download_id = 0)
	{
		#debug::print_d($download_id);
        if (is_numeric($download_id))
		{
            if (empty($this->download_sofort))
            {
                function is_leadtracker_installed()
                {
                    require_once(PAPOO_ABS_PFAD . "/lib/classes/intern_plugin_class.php");

                    $plugin->read_installed();
                    foreach($plugin->plugin_installed as &$plugininfo)
                    {
                        if($plugininfo['plugin_papoo_id'] == 98) {
                            return true;
                        }
                    }
                    return false;
                }
                //Erweiterung für das Leadtracker Plugin, läuft nur wenn das auch vorhanden ist
                // ... und installiert ist
                if (file_exists(PAPOO_ABS_PFAD."/plugins/leadtracker/lib/leadtracker_download.php") and is_leadtracker_installed())
                {
                    require_once(PAPOO_ABS_PFAD."/plugins/leadtracker/lib/leadtracker_download.php");
                    $leadtracker_download = new leadtracker_download_class();
                    $leadtracker_download->do_lead_tracker_download();

                    if (!$leadtracker_download->no_download_sofort) {
                        return false;
                    }
                }
            }

            //debug::print_d($download_id);
			// Prüfung ob Benutzer genügend Rechte hat um die Datei herunter zu laden
			if ($this->check_download_rights($download_id))
			{

                //exit();

				// Abfrage formulieren Downloads z�hlen
				$sql = "UPDATE " . $this->cms->papoo_download . " SET wieoft=wieoft+1, zeitpunkt=now() WHERE downloadid='" . $this->db->escape($download_id) . "'";
				//debug::Print_d($sql);exit();
				// Abfrage durchf�hren
				$this->db->query($sql);

				$sql2 = "SELECT  downloadname  FROM " . $this->cms->papoo_language_download . " WHERE download_id='" . $this->db->escape($download_id) . "' AND lang_id='".$this->cms->lang_id."'";
				$filename2 =$this->db->get_var($sql2);
				//$filename2=str_ireplace(" ","_",$filename2);

				// Downloaddatei rausholen
				$sql = "SELECT * FROM " . $this->cms->papoo_download . " WHERE downloadid='" . $this->db->escape($download_id) . "'";
				$resultiert = $this->db->get_results($sql);
				// f�r jedes Ergebnis durchgehen
				foreach ($resultiert as $rowdown)
				{
					// Filename berichtigen
					$filename = basename($rowdown->downloadlink);


					$this->do_redirect($this->cms->webverzeichnis . $rowdown->downloadlink);

					$datei_groesse = round(filesize(PAPOO_ABS_PFAD . $rowdown->downloadlink), 0) . "kB - ";
					// Wenn die Datei gr��er als $this->max_datei_groesse ist, Meta Refresh Download durchf�hren, da ansonsten bei langsamen Verbindungen Timeout droht!! Im Zweifel sogar noch kleiner machen!!!
					if ($datei_groesse > $this->max_datei_groesse && empty($this->download_sofort))
					{
						$this->refresh = '<meta http-equiv="refresh" content="0; url=' . $this->cms->webverzeichnis . $rowdown->downloadlink . '" />';
						$this->content->template['refresh'] = $this->refresh;


					}
					// Datei kleiner $this->max_datei_groesse
					else
					{
						//Gr��e ermitteln

						#echo $result[0]->downloadlink;
						if (file_exists(PAPOO_ABS_PFAD . $rowdown->downloadlink))
						{
							#echo "*";
							$size = filesize(PAPOO_ABS_PFAD . $rowdown->downloadlink);
						}
						// Header zuweisen
						header("Pragma: public");
						header("Expires: 0");
						header("Cache-Control: must-revalidate, post-check=0, pre-check=0");
						header("Content-Description: File Transfer");
						header("Accept-Ranges: bytes");
						//header("Content-Type: application/force-download");
						//header("Content-Type: application/download");
						// Wenn Opera oder MSIE auftauchen
						//if (preg_match('#Opera(/| )([0-9].[0-9]{1,2})#', getenv('HTTP_USER_AGENT')) or preg_match('#MSIE ([0-9].[0-9]{1,2})#', getenv('HTTP_USER_AGENT'))) {
						//	header("Content-Type: application/octetstream");
						//} else {
						//	header("Content-Type: application/octet-stream");
						//}

						// Mime-Type der Datei festestellen und Content-Type festlegen
						$fragmente = explode(".", $filename);
						$endung = $fragmente[count($fragmente) - 1];

						switch ($endung) {
							case "pdf" :
								header("Content-Type: application/pdf");
								break;
							case "zip" :
								header("Content-Type: application/zip");
								break;
							case "doc" :
								header("Content-Type: application/msword");
								break;
							case "txt" :
								header("Content-Type: text/plain");
								break;
							default :
								header("Content-Type: application/octet-stream");
						}

						header("Content-Length: $size ");
						// header("Pragma: no-cache");
						/*
						$browser = $_ENV['HTTP_USER_AGENT'];
						if (preg_match('/MSIE 5.5/', $browser) || preg_match('/MSIE 6.0/', $browser)) {
						header('Content-Disposition:  filename="'.$this->cms->webverzeichnis.$filename.'"');
						if (preg_match('/pdf/', $filename)) {
						header('Content-Disposition: attachment; filename="'.$this->cms->webverzeichnis.$filename.'"');
						}
						} else {
						header('Content-Disposition: attachment; filename="'.$this->cms->webverzeichnis.$filename.'"');
						}
						*/
						header('Content-Disposition: attachment; filename="' . utf8_decode($filename2) .'.'. $endung .'"');

						// Send Content-Transfer-Encoding HTTP header
						// (use binary to prevent files from being encoded/messed up during transfer)
						header('Content-Transfer-Encoding: binary');

						// File auslesen
						@readfile(PAPOO_ABS_PFAD . $rowdown->downloadlink);

						// Wichtig, sonst gibt es Chaos!
						exit;
					}
				}
			}
			// Benutzer hat keine Rechte zum herunterladen
			else
			{
				//echo "Keine Rechte zum herunterladen der Datei !";
				//$this->content->template['download']['kein_recht'];
			}

		}
		// Ende function download_file() #############
	}

	// Download-Link-Ersetzungen
	// =========================
	function replace_downloadlinks($text = "")
	{
		//echo $text;
		if ($text)
		{
			// 1. Feststellen ob Download-Links existieren
			$downloadlink_array = $this->find_downloadlinks($text);
			//print_r($downloadlink_array);

			if (!empty($downloadlink_array))
			{
				// 2. Wenn Download-Links existieren..
				foreach ($downloadlink_array as $link_array)
				{
					$old_link = $link_array[0];

                    // Wenn Link schon einmal bearbeitet, überspringe diesen
                    if(preg_match("/class=\"[^\"]*downloadlink/", $old_link))
                    {
                        continue;
                    }

					// Pr�fung ob Datei existiert
					if(!$this->check_download_file($link_array[2]))
					{
						$new_link = $link_array[3] . '<span style="font-size: 80%;"> ('.$this->content->template['download']['keine_datei'].')</span> ';
					}
					// Pr�fen ob Benutzer das Recht zum herunterladen hat
					elseif ($this->check_download_rights($link_array[2]) < 1)
					{
						// Keine Rechte zum herunterladen
						$nachlinktext = ' (<strong class="error">'.$this->content->template['download']['kein_recht'].'</strong>)';
						$new_link = $link_array[3] . $nachlinktext;
					}
					else
					{
                        // Menu-ID und Repore-ID in Download-Link ersetzen
                        $menuid = $this->checked->menuid;
                        $reporeid = $this->checked->reporeid;

						// Benutzer hat Rechte zum herunterladen:
                        if ($this->infos_anzeigen && $this->cms->do_replace_ok || $this->cms->do_replace_ok && $menuid == 1)
                        #if ($this->cms->do_replace_ok)
                        {
                            $nachlinktext = $this->get_downloadlink_text($link_array[2]);
                        }
						else $nachlinktext = "";

						// menuid mit 1 belegen, falls nicht vorhanden
						if ($menuid < 1) $menuid = 1;
						// reporeid mit 0 belegen, falls nicht vorhanden
						if ($reporeid < 1) $reporeid = 0;

						#echo "Menu: ".$menuid. "; Re-ID: ".$reporeid."; <br />";
						$link_array[0] = str_replace("=xxmenuidxx", "=".$menuid, $link_array[0]);
						$link_array[0] = str_replace("=xxreporeidxx", "=".$reporeid, $link_array[0]);
						//echo $link_array[0]."<br />";

						$new_link = $link_array[0] . $nachlinktext;

                        #echo $new_link; exit;

						// Downloads in einem neuen Fenster, !!! stimmt bei gro�en Dateien nicht

						//$new_link = str_replace(' href="', ' title="'.$this->content->template['download']['link_title'].'" class="downloadlink" href="', $new_link);
						// Erhalt der evtl. vergebenen CSS-Klasse
						if (strpos($old_link, ' class="'))
						{
							$new_link = str_replace(' class="', ' class="downloadlink ', $new_link);
						}
                        else
                        {
                            $new_link = str_replace(' href="', ' class="downloadlink" href="', $new_link);
                        }

						if(!stristr($new_link,'title')){
							$new_link = str_replace(' href="', ' title="'.$this->content->template['download']['link_title'].'" href="', $new_link);
						}

                        // VVV diese Zeilen wieder einbauen, wenn ein direkter Link erwuenscht ist VVV
                        // !!! ACHTUNG - die downloads koennen dann nicht mehr gezaehlt werden!
                        //
                        // Falls die Datei die Rechte "jeder" benötigt, dann ersetzen wir den Link
                        // durch den direkt Link
                        //
                        // global $db_praefix;
                        // $downloadid = $link_array[2];
                        // $sql = sprintf("SELECT downloadlink FROM (SELECT * FROM %s A RIGHT JOIN %s B ON A.downloadid = B.download_id_id WHERE B.gruppen_id_id=10) C WHERE downloadid='%s'", $db_praefix . "papoo_download", $db_praefix . "papoo_lookup_download", $this->db->escape($downloadid));
                        //
                        // $result = $this->db->get_results($sql, ARRAY_A);
                        // if(!empty($result)) {
                        //    $new_link = preg_replace("/href=\".*?\"/", "href=\"" . PAPOO_WEB_PFAD . $result[0]['downloadlink'] . "\"", $new_link);
                        // }
					}
					$text = str_replace($old_link, $new_link, $text);
				}
			}
		}
		return $text;
	}

	function find_downloadlinks($text)
	{
		//echo $text;
		$download_links = array ();
		$pattern = "/(<a [^>]{1,}downloadid=([0-9]*)[^>]{1,}>)(.*?)(<\/a>)/is";
		$anzahl = preg_match_all($pattern, $text, $download_links, PREG_SET_ORDER);
		#echo "Der Text hat insgesamt ".$anzahl." Download-Links.<br />";
		//print_r($download_links);

		if (!empty ($download_links))
			return $download_links;
		else
			return false;
	}

	// Test ob die Datei �berhaupt (noch) existiert.
	function check_download_file($id)
	{
		$sql = sprintf("SELECT downloadlink FROM %s WHERE downloadid='%d' LIMIT 1",
						$this->cms->papoo_download,
						$this->db->escape($id)
						);
		$link = $this->db->get_var($sql);



		#echo PAPOO_ABS_PFAD.$link;
		#echo "<br />";
		if (!empty($link) && file_exists(PAPOO_ABS_PFAD.$link)) return true;
		else return false;
	}

	// Sicherheitsabfrage formulieren, ob die Datei vom User herunter geladen werden darf oder nicht.
	function check_download_rights($id)
	{
		$sql = sprintf("SELECT COUNT(downloadid) FROM %s as T1, %s as T2, %s as T3
						WHERE T1.downloadid='%d' AND T1.downloadid=T2.download_id_id
						AND T2.gruppen_id_id=T3.gruppenid AND T3.userid='%d'
						LIMIT 1",
						$this->cms->papoo_download,
						$this->cms->papoo_lookup_download,
						$this->cms->papoo_lookup_ug,
						$this->db->escape($id),
						$this->user->userid);
        //debug::print_d($sql);
		return $this->db->get_var($sql);
	}

	function get_downloadlink_text($download_id = 0)
	{
		if ($download_id)
		{
			// Daten aus Tabelle download holen
			$query = sprintf("SELECT T1.downloadlink, T1.downloadgroesse,
							T1.wieoft, DATE_FORMAT(T1.zeitpunkt, '%%d.%%m.%%Y') as datum, T2.downloadname
							FROM %s as T1, %s as T2 WHERE T1.downloadid='%d' AND T1.downloadid=T2.download_id",
							$this->cms->papoo_download,
							$this->cms->papoo_language_download,
							$this->db->escape($download_id));
			//echo "QUERY: ".$query."<br />";
			$result = $this->db->get_results($query);
			//print_r($result);

			if (!empty ($result))
			{
				//Gr��e ermitteln

				//echo $result[0]->downloadlink;
				if (file_exists(PAPOO_ABS_PFAD . $result[0]->downloadlink))
				{
					//Verwendung von filesize macht das Handling mit gro�en Datein deutlich einfacher!!
					$datei_groesse = round(filesize(PAPOO_ABS_PFAD . $result[0]->downloadlink) / 1024, 0) . " kB";
					#$datei_groesse = round($result[0]->downloadgroesse / 1024, 0) . "kB - ";
					if ($datei_groesse > 1000)
					{
						$datei_groesse = round($datei_groesse / 1024, 2) . " MB";
					}

					if (strpos($result[0]->downloadlink, ".pdf"))
					{
						$icon_span = '<span class="pdf-icon" style="padding-left: 20px;'
										.' background-image: url('.$this->cms->webverzeichnis.'/bilder/icon_pdf.gif);'
										.' background-repeat: no-repeat; background-position: 5px 0px;"> </span>';
					}
					else $icon_span = "";

					//$text = "<small>" . $datei_icon . " (Gr&ouml;&szlig;e: " . $datei_groesse . " Downloads bisher: " . $result[0]->wieoft . "; Letzter Download am: " . $result[0]->datum . ") </small>";
					$text = $icon_span.'<span class="download-info" style="font-size: 80%;"> ('.$this->content->template['download']['info_01'].': '.$datei_groesse
							.'; '.$this->content->template['download']['info_02'].': '.$result[0]->wieoft
							.'; '.$this->content->template['download']['info_03'].': '.$result[0]->datum.')</span> ';
				}
				// Datei existiert nicht mehr
				else
				{
					$text = '<span style="font-size: 80%;"> ('.$this->content->template['download']['keine_datei'].')</span> ';
				}
			}
		}

		return $text;
	}
	// Ende Download-Link-Ersetzungen
	// ==============================
}

$download = new download_class();

?>
